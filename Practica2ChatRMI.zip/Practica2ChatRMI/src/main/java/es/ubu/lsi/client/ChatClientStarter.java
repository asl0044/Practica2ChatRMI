package es.ubu.lsi.client;

public class ChatClientStarter {

}
