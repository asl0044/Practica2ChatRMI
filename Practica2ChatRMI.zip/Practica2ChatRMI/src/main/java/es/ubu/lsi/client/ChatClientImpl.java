package es.ubu.lsi.client;

import java.rmi.RemoteException;

import es.ubu.lsi.common.ChatMessage;

public class ChatClientImpl implements ChatClient {

	public int getId() throws RemoteException {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setId(int id) throws RemoteException {
		// TODO Auto-generated method stub

	}

	public void receive(ChatMessage msg) throws RemoteException {
		// TODO Auto-generated method stub

	}

	public String getNickName() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

}
